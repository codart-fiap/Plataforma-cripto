package ProjetoTioPatinhas;

public class ContaPessoal extends Conta {
    String cpf;
    private int idPessoal = 1;

    public int getIdPessoal() {
        return idPessoal;
    }

    public int conectarConta(int idEmpresarial) {
        return 0;
    }
}
