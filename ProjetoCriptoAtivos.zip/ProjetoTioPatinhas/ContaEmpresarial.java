package ProjetoTioPatinhas;

public class ContaEmpresarial extends Conta {
    String cnpj;
    private int idEmpresarial = 2;

    public int getIdEmpresarial() {
        return idEmpresarial;
    }
}
